/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("joomtu.theme.Theme",
{
  meta :
  {
    color : joomtu.theme.Color,
    decoration : joomtu.theme.Decoration,
    font : joomtu.theme.Font,
    icon : qx.theme.icon.Tango,
    appearance : joomtu.theme.Appearance
  }
});