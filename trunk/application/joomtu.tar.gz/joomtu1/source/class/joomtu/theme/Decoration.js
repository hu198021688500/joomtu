/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("joomtu.theme.Decoration",
{
  extend : qx.theme.modern.Decoration,

  decorations :
  {
  }
});