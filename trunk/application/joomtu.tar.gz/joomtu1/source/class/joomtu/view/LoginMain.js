/*
#asset(joomtu/login/site_logo.png)
#asset(qx/icon/${qx.icontheme}/48/apps/preferences-users.png)
*/

qx.Class.define("joomtu.view.LoginMain",{
	extend:qx.ui.container.Composite,
	events : {
		"changeLoginData" : "qx.event.type.Data"
	},
	construct:function(){
		this.base(arguments);
		this.set({
			layout:new qx.ui.layout.Canvas()
		});
		this.add(this.__createLoginUI(),{left:"38%",top:"38%"});
		this.add(this.__createCopyRight(),{left:"25%",bottom:"2%"});
	},
	members:{
		__createLoginUI:function(){
			var composite = new qx.ui.container.Composite(new qx.ui.layout.VBox());
			composite.add(this.__createTitle());
			var composite1 = new qx.ui.container.Composite(new qx.ui.layout.HBox());
			composite1.add(this.__createSiteLogo());
			composite1.add(this.__createLoginForm());
			composite.add(composite1);
			return composite;
		},
		__createTitle:function(){
			var atom = new qx.ui.basic.Atom(this.tr("Welcome user joomt admin manager system"), "icon/48/apps/preferences-users.png");
			atom.setFont(new qx.bom.Font(16, ["Tahoma","Liberation Sans","Arial"]));
			return atom;
		},
		__createSiteLogo:function(){
			var siteLogo = new qx.ui.basic.Image("joomtu/login/site_logo.png");
			siteLogo.setWidth(100);
			siteLogo.setHeight(100);
			return siteLogo;
		},
		__createLoginForm:function(){
			var form = new qx.ui.form.Form();
			
			var usernameComboBox = new qx.ui.form.ComboBox();
			usernameComboBox.setPlaceholder(this.tr("username"));
			usernameComboBox.setRequired(true);
			usernameComboBox.add(new qx.ui.form.ListItem("root"));
			usernameComboBox.add(new qx.ui.form.ListItem("admin"));
			form.add(usernameComboBox, this.tr("Username"), null, "username");
			
			var passwordField = new qx.ui.form.PasswordField();
			passwordField.setPlaceholder(this.tr("password"));
			passwordField.setRequired(true);
			form.add(passwordField, this.tr("Password"), null, 'password');
			
			var remember = new qx.ui.form.CheckBox(this.tr("Remember username"));
			form.add(remember, "");
			
			var controller = new qx.data.controller.Form(null, form);
			var model = controller.createModel();
			
			var loginButton = new qx.ui.form.Button(this.tr("Login"));
			loginButton.addListener("execute", function() {
				if (form.validate()) {
					var loginRequest = new qx.io.request.Xhr();
					loginRequest.setData(controller.getModel().getBindings());
					loginRequest.setUrl("test.php");
					loginRequest.setMethod("POST");
					loginRequest.setp
					loginRequest.send();
					var result = loginRequest.getResponseText();
					var loginRequest = new qx.data.store.Json("test.php");
					loginRequest.setModel(model);
					loginRequest.
					alert(result);
					var loginData = {
						username : controller.getModel().getUsername(),
					 	password : controller.getModel().getPassword()
					};
					//this.fireDataEvent("changeLoginData", loginData);
					//this.close();
					alert("send...");
					qx.bom.Cookie.set("loginHistory[]","hu1",100);
					//qx.bom.Cookie.set("loginHistory[]","hu2",100);
					//qx.bom.Cookie.set("loginHistory[]","hu3",100);
				}
			}, this);
			form.addButton(loginButton);
			
			var resetButton = new qx.ui.form.Button(this.tr("Reset"));
			resetButton.addListener("execute", function() {
				form.reset();
			}, this);
			form.addButton(resetButton);
			
			return new qx.ui.form.renderer.Single(form);
		},
		__createCopyRight:function(){
			var copyRight = new qx.ui.basic.Label();
			//copyRight.setAppearance("myimage");
			//copyRight.setFont("bold");
			//copyRight.setDecorator();
			copyRight.setRich(true);
			copyRight.setValue(
				"<b>Client side form validation</b>"
				+ "All fields are required. Some by a custom validator, some by a "
				+ "predefined validator and some by the required flag."
			);
			return copyRight;
		}
	}
});